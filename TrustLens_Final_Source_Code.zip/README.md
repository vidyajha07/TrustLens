# TrustLens

TrustLens is a privacy-aware prototype for assessing unusual transactions. The Flutter interface sends sample transaction signals to a FastAPI backend. The backend returns an explainable risk level and stores privacy-minimised event history in PostgreSQL.

## Repository layout

- `backend/` contains the FastAPI risk-assessment API and PostgreSQL integration.
- `frontend/lib/` contains the Flutter user interface.

## Run the backend

From `backend/`, copy `.env.example` to `.env`, then enter your local PostgreSQL password in `.env`. Never upload `.env` to GitHub.

Create and activate a Python environment, install the dependencies, then run:

```powershell
python -m pip install -r requirements.txt
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

The API runs at http://127.0.0.1:8000. Interactive documentation is available at http://127.0.0.1:8000/docs.

## Run the frontend

Inside a Flutter project, copy `frontend/lib/main.dart` into `lib/main.dart`. Then install the HTTP package and run:

```powershell
flutter pub add http
flutter run -d chrome
```

Keep the backend running while using the Flutter application.

If the frontend runs on a different laptop on the same private Wi-Fi/hotspot,
start FastAPI with the command above and use the backend laptop's IPv4 address:

```powershell
flutter run -d chrome --dart-define=TRUSTLENS_API_URL=http://BACKEND-LAPTOP-IP:8000
```

`0.0.0.0` is a server binding address, not a browser address. Open `/docs` using
`127.0.0.1` on the backend laptop or the backend laptop's IPv4 address from the frontend laptop.

## Privacy notes

This prototype uses sample data only. It does not collect card numbers, CVV, PINs, or OTPs. Location context is optional. PostgreSQL receives a pseudonymous user reference, amount range, time, boolean context signals, risk result, and a keyed merchant fingerprint—not a raw merchant name. The permissive CORS configuration is for local development only and must be restricted before deployment.

## Next steps

Use the privacy-minimised history to build a more personalised Pattern Reader, add authentication, and package the Flutter interface for Android.
