import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// Use --dart-define=TRUSTLENS_API_URL=http://BACKEND-LAPTOP-IP:8000
// when the frontend and backend run on separate devices.
const apiBaseUrl = String.fromEnvironment(
  'TRUSTLENS_API_URL',
  defaultValue: 'http://127.0.0.1:8000',
);

void main() => runApp(const TrustLensApp());

class TrustLensApp extends StatelessWidget {
  const TrustLensApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'TrustLens',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark().copyWith(
          scaffoldBackgroundColor: const Color(0xFF0F0F14),
        ),
        home: const TrustLensSafetyScreen(),
      );
}

class TrustLensSafetyScreen extends StatefulWidget {
  const TrustLensSafetyScreen({super.key});

  @override
  State<TrustLensSafetyScreen> createState() =>
      _TrustLensSafetyScreenState();
}

class _TrustLensSafetyScreenState extends State<TrustLensSafetyScreen> {
  Map<String, dynamic>? evaluationResult;
  bool isLoading = true;
  String errorMessage = '';
  bool isTravelCity = false;
  bool isKnownSubscription = false;
  bool isSharedSpend = false;

  final transactionData = <String, dynamic>{
    'amount': 12000.0,
    'hour_of_day': 2,
    'is_new_device': 1,
  };

  @override
  void initState() {
    super.initState();
    evaluateTransaction();
  }

  Future<void> evaluateTransaction() async {
    setState(() {
      isLoading = true;
      errorMessage = '';
    });
    try {
      final response = await http.post(
        Uri.parse('$apiBaseUrl/assess-transaction'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'user_reference': 'vidya-demo',
          'amount': transactionData['amount'],
          'merchant': 'Online Merchant Purchase',
          'hour': transactionData['hour_of_day'],
          'new_device': transactionData['is_new_device'] == 1,
          'travelling': isTravelCity,
          'known_subscription': isKnownSubscription,
          'shared_family_spend': isSharedSpend,
        }),
      );
      if (response.statusCode != 200) {
        throw Exception('Backend returned ${response.statusCode}');
      }
      if (!mounted) return;
      setState(() {
        evaluationResult = jsonDecode(response.body) as Map<String, dynamic>;
        isLoading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        isLoading = false;
        errorMessage = 'Could not reach TrustLens. Ensure FastAPI is running.';
      });
    }
  }

  Color get riskColor {
    switch (evaluationResult?['risk_level']) {
      case 'High':
        return Colors.redAccent;
      case 'Medium':
        return Colors.orangeAccent;
      case 'Low':
        return Colors.greenAccent;
      default:
        return Colors.blueAccent;
    }
  }

  String get riskLabel {
    if (isLoading) return 'Checking transaction';
    if (errorMessage.isNotEmpty) return 'Connection error';
    return '${evaluationResult?['risk_level'] ?? 'Unknown'} Risk Alert';
  }

  @override
  Widget build(BuildContext context) {
    final amount = transactionData['amount'] as double;
    final hour = transactionData['hour_of_day'] as int;
    return Scaffold(
      appBar: AppBar(
        title: const Text('TrustLens Safety'),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Icon(Icons.shield_outlined),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _riskBadge(),
            const SizedBox(height: 20),
            _transactionCard(amount, hour),
            const SizedBox(height: 24),
            const Text('LIVE CONTEXT CONTROLS',
                style: TextStyle(
                    color: Colors.grey,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1)),
            const SizedBox(height: 12),
            _contextControls(),
            const SizedBox(height: 24),
            _actionCard(),
            const SizedBox(height: 16),
            const Row(children: [
              Icon(Icons.lock_outline, size: 16, color: Colors.tealAccent),
              SizedBox(width: 8),
              Expanded(
                  child: Text(
                      'Privacy-safe demo: no card number, CVV, PIN, OTP, or exact location is stored.',
                      style: TextStyle(color: Colors.grey, fontSize: 12))),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _riskBadge() => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: riskColor.withOpacity(0.15),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: riskColor.withOpacity(0.5)),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.warning_amber_rounded, color: riskColor, size: 18),
          const SizedBox(width: 6),
          Text(riskLabel,
              style: TextStyle(color: riskColor, fontWeight: FontWeight.bold)),
        ]),
      );

  Widget _transactionCard(double amount, int hour) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: const Color(0xFF1B1B22),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('₹${amount.toInt()}',
              style:
                  const TextStyle(fontSize: 36, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          const Text('Online Merchant Purchase',
              style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 20),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            _infoTile('Time', '$hour:00 AM'),
            _infoTile('Device',
                transactionData['is_new_device'] == 1 ? 'New Device' : 'Known Device'),
            _infoTile('Location', isTravelCity ? 'Travel Context' : 'Not shared'),
          ]),
        ]),
      );

  Widget _contextControls() => Material(
        color: const Color(0xFF1B1B22),
        borderRadius: BorderRadius.circular(16),
        child: Column(children: [
          SwitchListTile(
            title: const Text('Travel City Context'),
            subtitle: const Text('Optional context; no exact location is stored.',
                style: TextStyle(fontSize: 12)),
            value: isTravelCity,
            activeColor: Colors.blueAccent,
            onChanged: (value) {
              setState(() => isTravelCity = value);
              evaluateTransaction();
            },
          ),
          SwitchListTile(
            title: const Text('Known Subscription Charge'),
            value: isKnownSubscription,
            activeColor: Colors.blueAccent,
            onChanged: (value) {
              setState(() => isKnownSubscription = value);
              evaluateTransaction();
            },
          ),
          SwitchListTile(
            title: const Text('Shared Family Spend'),
            value: isSharedSpend,
            activeColor: Colors.blueAccent,
            onChanged: (value) {
              setState(() => isSharedSpend = value);
              evaluateTransaction();
            },
          ),
        ]),
      );

  Widget _actionCard() {
    final action = isLoading
        ? 'Checking the transaction with TrustLens…'
        : errorMessage.isNotEmpty
            ? errorMessage
            : evaluationResult?['recommended_action'] ??
                'No recommended action available.';
    final reasons =
        List<String>.from(evaluationResult?['reasons'] ?? <String>[]);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: riskColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: riskColor.withOpacity(0.3)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('RECOMMENDED SYSTEM ACTION',
            style: TextStyle(color: Colors.grey, fontSize: 12)),
        const SizedBox(height: 6),
        Text(action,
            style: TextStyle(
                color: riskColor, fontSize: 17, fontWeight: FontWeight.bold)),
        if (reasons.isNotEmpty) ...[
          const SizedBox(height: 14),
          const Text('WHY THIS WAS FLAGGED',
              style: TextStyle(color: Colors.grey, fontSize: 12)),
          const SizedBox(height: 6),
          ...reasons.map((reason) => Padding(
                padding: const EdgeInsets.only(top: 5),
                child: Row(children: [
                  const Icon(Icons.info_outline,
                      size: 16, color: Colors.white70),
                  const SizedBox(width: 8),
                  Expanded(
                      child: Text(reason,
                          style: const TextStyle(color: Colors.white70))),
                ]),
              )),
        ],
      ]),
    );
  }

  Widget _infoTile(String label, String value) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(color: Colors.grey, fontSize: 12)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      );
}
