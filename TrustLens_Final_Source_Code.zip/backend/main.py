import hashlib
import hmac
import os
from datetime import datetime, timezone
from typing import List

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import URL, Boolean, DateTime, Integer, String, create_engine, text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

load_dotenv()

app = FastAPI(title="TrustLens API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Local development only.
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)

database_url = URL.create(
    "postgresql+psycopg",
    username=os.getenv("DB_USER"),
    password=os.getenv("DB_PASSWORD"),
    host=os.getenv("DB_HOST", "127.0.0.1"),
    port=int(os.getenv("DB_PORT", "5432")),
    database=os.getenv("DB_NAME", "trustlens"),
)
engine = create_engine(database_url, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine)


class Base(DeclarativeBase):
    pass


class TransactionEvent(Base):
    """Privacy-minimised event record; raw merchant names are never stored."""

    __tablename__ = "transaction_events"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_reference: Mapped[str] = mapped_column(String(64), index=True)
    amount_band: Mapped[str] = mapped_column(String(20))
    merchant_fingerprint: Mapped[str] = mapped_column(String(64))
    hour: Mapped[int] = mapped_column(Integer)
    new_device: Mapped[bool] = mapped_column(Boolean)
    travel_context_shared: Mapped[bool] = mapped_column(Boolean)
    known_subscription: Mapped[bool] = mapped_column(Boolean)
    shared_family_spend: Mapped[bool] = mapped_column(Boolean, default=False)
    risk_level: Mapped[str] = mapped_column(String(10))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class Transaction(BaseModel):
    user_reference: str = Field(default="demo-user-001", max_length=64)
    amount: float
    merchant: str
    hour: int = Field(ge=0, le=23)
    new_device: bool = False
    travelling: bool = False
    known_subscription: bool = False
    shared_family_spend: bool = False


@app.on_event("startup")
def create_tables():
    Base.metadata.create_all(bind=engine)
    with engine.begin() as connection:
        connection.execute(text("ALTER TABLE transaction_events ADD COLUMN IF NOT EXISTS shared_family_spend BOOLEAN NOT NULL DEFAULT FALSE"))


def amount_band(amount: float) -> str:
    if amount < 1000:
        return "under-1000"
    if amount < 5000:
        return "1000-to-4999"
    if amount < 10000:
        return "5000-to-9999"
    return "10000-or-more"


def merchant_fingerprint(merchant: str) -> str:
    secret = os.getenv("MERCHANT_HASH_SECRET", "")
    return hmac.new(
        secret.encode(), merchant.strip().lower().encode(), hashlib.sha256
    ).hexdigest()


def assess_risk(transaction: Transaction) -> tuple[str, List[str], str]:
    score = 0
    reasons = []
    if transaction.amount > 10000:
        score += 2
        reasons.append("High transaction amount")
    if transaction.hour < 6:
        score += 1
        reasons.append("Unusual transaction time")
    if transaction.new_device:
        score += 2
        reasons.append("New device detected")
    if transaction.travelling:
        score -= 1
        reasons.append("Travel context found")
    if transaction.known_subscription:
        score -= 2
        reasons.append("Known subscription found")
    if transaction.shared_family_spend:
        score -= 1
        reasons.append("Shared family-spend context found")
    if score >= 4:
        return "High", reasons, "Ask the user to secure the account."
    if score >= 2:
        return "Medium", reasons, "Ask the user to confirm the transaction."
    return "Low", reasons, "Explain the transaction and reassure the user."


@app.get("/")
def home():
    return {"message": "TrustLens API is running"}


@app.post("/assess-transaction")
def assess_transaction(transaction: Transaction):
    risk_level, reasons, action = assess_risk(transaction)
    event = TransactionEvent(
        user_reference=transaction.user_reference,
        amount_band=amount_band(transaction.amount),
        merchant_fingerprint=merchant_fingerprint(transaction.merchant),
        hour=transaction.hour,
        new_device=transaction.new_device,
        travel_context_shared=transaction.travelling,
        known_subscription=transaction.known_subscription,
        shared_family_spend=transaction.shared_family_spend,
        risk_level=risk_level,
        created_at=datetime.now(timezone.utc),
    )
    database = SessionLocal()
    try:
        database.add(event)
        database.commit()
        database.refresh(event)
    finally:
        database.close()
    return {
        "transaction_id": event.id,
        "risk_level": risk_level,
        "reasons": reasons,
        "recommended_action": action,
    }


@app.get("/transaction-history/{user_reference}")
def transaction_history(user_reference: str):
    database = SessionLocal()
    try:
        events = (
            database.query(TransactionEvent)
            .filter(TransactionEvent.user_reference == user_reference)
            .order_by(TransactionEvent.created_at.desc())
            .limit(10)
            .all()
        )
        return [
            {
                "id": event.id,
                "amount_band": event.amount_band,
                "hour": event.hour,
                "risk_level": event.risk_level,
                "created_at": event.created_at,
            }
            for event in events
        ]
    finally:
        database.close()
