import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const TrustLensApp());
}

class TrustLensApp extends StatelessWidget {
  const TrustLensApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TrustLens',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0F0F1A),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF6C5CE7),
          secondary: Color(0xFFFF7675),
          surface: Color(0xFF1E1E2E),
        ),
      ),
      home: const AlertScreen(),
    );
  }
}

class AlertScreen extends StatefulWidget {
  const AlertScreen({super.key});

  @override
  State<AlertScreen> createState() => _AlertScreenState();
}

class _AlertScreenState extends State<AlertScreen> {
  final double amount = 12000;
  final String merchant = 'Online Merchant Purchase';
  final int hour = 2;
  final bool newDevice = true;
  bool shareLocationContext = false;
  bool isLoading = false;
  String riskLevel = 'Not checked';
  String action = 'Tap Analyse transaction to contact the TrustLens backend.';
  List<String> reasons = [];

  Future<void> assessTransaction() async {
    setState(() => isLoading = true);

    try {
      final response = await http.post(
        Uri.parse('http://127.0.0.1:8000/assess-transaction'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'amount': amount,
          'merchant': merchant,
          'hour': hour,
          'new_device': newDevice,
          'travelling': shareLocationContext,
          'known_subscription': false,
        }),
      );

      if (response.statusCode != 200) {
        throw Exception('Backend returned ${response.statusCode}');
      }

      final result = jsonDecode(response.body) as Map<String, dynamic>;
      setState(() {
        riskLevel = result['risk_level'] as String;
        action = result['recommended_action'] as String;
        reasons = List<String>.from(result['reasons'] as List);
      });
    } catch (_) {
      setState(() {
        riskLevel = 'Connection error';
        action = 'Start FastAPI on port 8000, then try again.';
        reasons = [];
      });
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  Color get riskColor {
    if (riskLevel == 'High') return const Color(0xFFFF7675);
    if (riskLevel == 'Medium') return const Color(0xFFFFC857);
    if (riskLevel == 'Low') return const Color(0xFF49D6AE);
    return const Color(0xFF6C5CE7);
  }

  @override
  Widget build(BuildContext context) {
    final locationText = shareLocationContext ? 'Shared for this check' : 'Not shared';

    return Scaffold(
      appBar: AppBar(
        title: const Text('TrustLens Safety', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        actions: [
          IconButton(
            tooltip: 'Privacy settings',
            icon: const Icon(Icons.shield_outlined, color: Color(0xFF6C5CE7)),
            onPressed: () => _showPrivacySettings(),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _riskBadge(),
              const SizedBox(height: 20),
              _transactionCard(locationText),
              const SizedBox(height: 20),
              const Text('BACKEND RISK ANALYSIS', style: TextStyle(color: Colors.grey, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
              const SizedBox(height: 10),
              _analysisCard(),
              const SizedBox(height: 14),
              const Row(children: [
                Icon(Icons.lock_outline, color: Color(0xFF8DE5CF), size: 16),
                SizedBox(width: 8),
                Expanded(child: Text('Demo uses sample data. No card number, CVV, PIN, or OTP is collected.', style: TextStyle(color: Color(0xFFB8D7D0), fontSize: 12))),
              ]),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton.icon(
                  onPressed: isLoading ? null : assessTransaction,
                  icon: isLoading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.analytics_outlined),
                  label: Text(isLoading ? 'Checking with backend...' : 'Analyse transaction'),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: OutlinedButton(
                  onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Security request recorded for this demo.'))),
                  style: OutlinedButton.styleFrom(side: const BorderSide(color: Color(0xFFFF7675), width: 1.5)),
                  child: const Text('Secure my card', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFFF7675))),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _riskBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: riskColor.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: riskColor),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.warning_amber_rounded, color: riskColor, size: 18),
        const SizedBox(width: 8),
        Text('Risk: $riskLevel', style: TextStyle(color: riskColor, fontWeight: FontWeight.bold, fontSize: 13)),
      ]),
    );
  }

  Widget _transactionCard(String locationText) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: const Color(0xFF1E1E2E), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white10)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('₹${amount.toStringAsFixed(0)}', style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(merchant, style: const TextStyle(color: Colors.grey)),
        const Divider(height: 30, color: Colors.white10),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          _meta('Time', '2:00 AM'),
          _meta('Device', 'New device'),
          _meta('Location', locationText),
        ]),
      ]),
    );
  }

  Widget _meta(String label, String value) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
    const SizedBox(height: 4),
    Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
  ]);

  Widget _analysisCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: const Color(0xFF161625), borderRadius: BorderRadius.circular(16), border: Border.all(color: riskColor.withValues(alpha: 0.4))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(action, style: const TextStyle(color: Colors.white70, height: 1.4)),
        if (reasons.isNotEmpty) ...[
          const SizedBox(height: 12),
          ...reasons.map((reason) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(children: [const Icon(Icons.info_outline, size: 16, color: Colors.white54), const SizedBox(width: 8), Expanded(child: Text(reason, style: const TextStyle(color: Colors.grey, fontSize: 13)))]),
          )),
        ],
      ]),
    );
  }

  void _showPrivacySettings() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1E2E),
      builder: (context) => StatefulBuilder(builder: (context, setSheetState) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Privacy settings', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            const Text('Location context is optional and is only sent after you choose to share it.', style: TextStyle(color: Colors.white70)),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Share location context'),
              value: shareLocationContext,
              onChanged: (value) {
                setState(() => shareLocationContext = value);
                setSheetState(() {});
              },
            ),
            SizedBox(width: double.infinity, child: ElevatedButton(onPressed: () => Navigator.pop(context), child: const Text('Save privacy choice'))),
          ]),
        ),
      )),
    );
  }
}


