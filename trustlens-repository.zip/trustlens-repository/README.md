# TrustLens

TrustLens is a privacy-aware prototype for assessing unusual transactions. The Flutter interface sends sample transaction signals to a FastAPI backend, which returns an explainable risk level and recommended action.

## Repository layout

- `backend/` contains the FastAPI risk-assessment API.
- `frontend/lib/` contains the Flutter user interface.

## Run the backend

From `backend/`, create and activate a Python environment, install FastAPI and Uvicorn, then run:

```powershell
python -m pip install fastapi "uvicorn[standard]"
python -m uvicorn main:app --reload
```

The API runs at http://127.0.0.1:8000. Interactive documentation is available at http://127.0.0.1:8000/docs.

## Run the frontend

Inside a Flutter project, copy `frontend/lib/main.dart` into `lib/main.dart`. Then install the HTTP package and run:

```powershell
flutter pub add http
flutter run -d chrome
```

Keep the backend running while using the Flutter application.

## Privacy notes

This prototype uses sample data only. It does not collect card numbers, CVV, PINs, or OTPs. Location context is optional. The permissive CORS configuration in the backend is for local development only and must be restricted before deployment.

## Next steps

Add PostgreSQL to retain privacy-minimised transaction history, then use it to build the Pattern Reader.

