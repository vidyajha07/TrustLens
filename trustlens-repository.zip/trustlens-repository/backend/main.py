from typing import List

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="TrustLens API")

# Development-only setting so the Flutter browser app can call this local API.
# Replace "*" with the real frontend domain before deployment.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["POST", "GET"],
    allow_headers=["Content-Type"],
)


class Transaction(BaseModel):
    amount: float
    merchant: str
    hour: int
    new_device: bool = False
    travelling: bool = False
    known_subscription: bool = False


def assess_risk(transaction: Transaction) -> tuple[str, List[str], str]:
    score = 0
    reasons = []

    if transaction.amount > 10000:
        score += 2
        reasons.append("High transaction amount")

    if transaction.hour < 6:
        score += 1
        reasons.append("Unusual transaction time")

    if transaction.new_device:
        score += 2
        reasons.append("New device detected")

    if transaction.travelling:
        score -= 1
        reasons.append("Travel context found")

    if transaction.known_subscription:
        score -= 2
        reasons.append("Known subscription found")

    if score >= 4:
        return "High", reasons, "Ask the user to secure the account."
    if score >= 2:
        return "Medium", reasons, "Ask the user to confirm the transaction."
    return "Low", reasons, "Explain the transaction and reassure the user."


@app.get("/")
def home():
    return {"message": "TrustLens API is running"}


@app.post("/assess-transaction")
def assess_transaction(transaction: Transaction):
    risk_level, reasons, action = assess_risk(transaction)
    return {
        "risk_level": risk_level,
        "reasons": reasons,
        "recommended_action": action,
    }


